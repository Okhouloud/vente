import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { Observable } from 'rxjs';

@Injectable({
  providedIn: 'root'
})
export class ProductsService {

  //  server url
  url: 'http://54.38.33.183:8081/hardware/api/categories';

  constructor(private http: HttpClient) { }//yasna3 fi var http de type HtppClient

    /** GET products from the server */
    getProducts (): Observable<any> {
      return this.http.get('http://54.38.33.183:8081/hardware/api/categories');
    }

    /** GET static products */
    getProductsStatic () {
      let products = [
        {name: 'pc asus', prix: "2500", option: 'wifi',id:0},
        {name: 'pc dell', prix: "1500", option: 'hifi',id:1},
        {name: 'pc fujitsu', prix: "1300", option: 'hifi',id:2},

      ]
      return products;
    }

    getProductByIdStatic(id) {
      let products=[
        {name: 'pc asus', prix: "2500", option: 'wifi',id:0},
        {name: 'pc dell', prix: "1500", option: 'hifi',id:1},
        {name: 'pc fujitsu', prix: "1300", option: 'hifi',id:2},
        ]
      return products[id]
    }

    getProductById(id) {
      return this.http.get('http://54.38.33.183:8081/hardware/api/categories/' + id);
    }
}
